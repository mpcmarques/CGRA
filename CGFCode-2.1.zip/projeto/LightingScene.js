var degToRad = Math.PI / 180.0;

function LightingScene() {
	CGFscene.call(this);
}

LightingScene.prototype = Object.create(CGFscene.prototype);
LightingScene.prototype.constructor = LightingScene;

LightingScene.prototype.init = function(application) {
	CGFscene.prototype.init.call(this, application);

	this.initCameras();

	this.initLights();

	this.gl.clearColor(0.0, 191/255, 1.0, 1.0);
	this.gl.clearDepth(100.0);
	this.gl.enable(this.gl.DEPTH_TEST);
	this.gl.enable(this.gl.CULL_FACE);
	this.gl.depthFunc(this.gl.LEQUAL);

	this.axis = new CGFaxis(this);

	//	Enables textures
	this.enableTextures(true);

	//	enable timer
	this.setUpdatePeriod(1000);

	// interface
	this.option1 = true;
	this.option2 = false;
	this.speed = 3;

	/* SUBMARINE */
	this.submarineX = 5;
	this.submarineZ = 5;
	this.submarineY = 0;
	this.submarineAngle = Math.PI - Math.PI/6;

	/* Scene Elements */

	// Submarine
	this.submarine = new MySubmarine(this);

	// Plane
	this.plane = new Plane(this, 10, 0, 5, 0, 5);

	// Poste
	this.poste = new MyCilinder(this, 10, 6);

	// Relogio
	this.clock = new MyClock(this);

	/* Appearances */

	// default appearance
	this.greenAppearance = new CGFappearance(this);
	this.greenAppearance.setSpecular(0.3,0.5,1,1);
	this.greenAppearance.setDiffuse(0.1,0.1,0.1,1);
	this.greenAppearance.setAmbient(0,0,1);
	this.greenAppearance.setShininess(10);

	//	water appearance
	this.waterAppearance = new CGFappearance(this);
	this.waterAppearance.loadTexture("../resources/images/underwater_ground.jpg");
	this.waterAppearance.setTextureWrap('REPEAT', 'REPEAT');
	this.waterAppearance.setSpecular(0.2,0.2,0.2,1);
	this.waterAppearance.setDiffuse(0.8,0.8,0.8,1);
	this.waterAppearance.setShininess(30);

};

LightingScene.prototype.initCameras = function() {
	this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(30, 30, 30), vec3.fromValues(0, 0, 0));
};

LightingScene.prototype.initLights = function() {
	this.setGlobalAmbientLight(0.4,0.4,0.4, 1.0);
	
	// Positions for light
	this.lights[0].setPosition(5, 8, 5, 1);
	
	// light setup
	this.lights[0].setAmbient(0, 0, 0, 1);
	this.lights[0].setSpecular(1,1,1,1);
	this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[0].enable();
};

LightingScene.prototype.updateLights = function() {
	for (i = 0; i < this.lights.length; i++)
		this.lights[i].update();
}


LightingScene.prototype.display = function() {
	// ---- BEGIN Background, camera and axis setup

	// Clear image and depth buffer everytime we update the scene
	this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
	this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);

	// Initialize Model-View matrix as identity (no transformation)
	this.updateProjectionMatrix();
	this.loadIdentity();

	// Apply transformations corresponding to the camera position relative to the origin
	this.applyViewMatrix();

	// Update all lights used
	this.updateLights();

	// Draw axis
	this.axis.display();


	// ---- END Background, camera and axis setup

	// ---- BEGIN Geometric transformation section

	// ---- END Geometric transformation section


	// ---- BEGIN Primitive drawing section

	/* Scene Elements */

	// submarine
	this.pushMatrix();
		this.translate(this.submarineX, this.submarineY, this.submarineZ);
		this.rotate(this.submarineAngle,0,1,0);
		this.greenAppearance.apply();
		this.submarine.display();
	this.popMatrix();

	// plane
	this.pushMatrix();
		this.translate(5, 0, 5);	
		this.rotate(Math.PI/2, 1,0,0);
		this.rotate(Math.PI,0,1,0);
		this.scale(10,10,1);
		// appearance
		this.waterAppearance.apply();
		this.plane.display();
	this.popMatrix();

	// poste
	this.pushMatrix();
		this.translate(8,0,0);
		this.rotate(-Math.PI/2,1,0,0);
		this.poste.display();
	this.popMatrix();

	// clock
	this.pushMatrix();
		this.translate(8,5,0.5);
		this.clock.display();
	this.popMatrix();
	// ---- END Primitive drawing section
};

// update function
LightingScene.prototype.update = function(currTime){
	this.clock.update(currTime);
}

// Do something function
LightingScene.prototype.doSomething = function(){
	console.log("Doing something..");
};

// Rotate submarine
LightingScene.prototype.rotateSubmarine = function(rotation){
	this.submarineAngle += rotation;
};

// Move submarine
LightingScene.prototype.moveSubmarine = function(isForward){
	var deltaX = Math.sin(this.submarineAngle);
	var deltaZ = Math.cos(-this.submarineAngle);
	
	if(isForward == true){
		this.submarineX += deltaX;
		this.submarineZ += deltaZ;
	} else {
		this.submarineX -= deltaX;
		this.submarineZ -= deltaZ;
	}
}

