/**
 * MySubmarine
 * @param gl {WebGLRenderingContext}
 * @constructor
 */
function MySubmarine(scene) {
	CGFobject.call(this,scene);

	//	Init buffers
	this.initBuffers();
};
MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor=MySubmarine;

MySubmarine.prototype.initBuffers = function () {
	
	this.vertices = [
            -0.5, 0, 0,
            0.5, 0, 0,
            0, 0.3, 2,
			];

	this.indices = [
            2,1,0
        ];
		
	this.normals = [
		0,0,1,
		0,0,1,
		0,0,1
	];

	this.primitiveType=this.scene.gl.TRIANGLES;
	this.initGLBuffers();
};

MySubmarine.prototype.addTextureCoords = function(minS, maxS, minT, maxT){

	this.texCoords = [minS,minT,
	maxS,minT,
	minS,maxT,
	maxS,maxT];
	
};